-- Bidwise AI – Supabase duomenų bazės schema
-- Vykdykite šiuos SQL komandus Supabase SQL Editor

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  name text,
  password_hash text not null,
  plan text default 'free',
  free_analyses_left int default 3,
  stripe_customer_id text,
  subscription_end timestamp,
  created_at timestamp default now()
);

create table if not exists analyses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id) on delete cascade,
  document_name text,
  score int,
  result_json jsonb,
  created_at timestamp default now()
);

-- Indeksai greitesnėms užklausoms
create index if not exists analyses_user_id_idx on analyses(user_id);
create index if not exists analyses_created_at_idx on analyses(created_at desc);
create index if not exists users_email_idx on users(email);

-- Row Level Security (rekomenduojama)
alter table users enable row level security;
alter table analyses enable row level security;

-- Service key apeina RLS, todėl backend veiks be papildomų policijų
