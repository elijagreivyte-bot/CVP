# Bidwise AI – Pilnas diegimo vadovas

## Projekto struktūra
```
bidwise-ai/
├── vercel.json           ← Vercel konfigūracija
├── package.json          ← npm priklausomybės
├── supabase-schema.sql   ← DB lentelės (vykdykite Supabase)
├── public/
│   └── index.html        ← Visas frontend (landing + app)
└── api/
    ├── register.js       ← POST /api/register
    ├── login.js          ← POST /api/login
    ├── analyze.js        ← POST /api/analyze (AI analizė)
    ├── analyses.js       ← GET /api/analyses (istorija)
    ├── send-email.js     ← POST /api/send-email
    ├── create-checkout.js← POST /api/create-checkout (Stripe)
    └── stripe-webhook.js ← POST /api/stripe-webhook
```

---

## ŽINGSNIS PO ŽINGSNIO DIEGIMAS

### 1. Supabase (duomenų bazė) – NEMOKAMA
1. Eikite į **supabase.com** → Create new project
2. Pasirinkite regioną **eu-central-1** (Frankfurt)
3. Nukopijuokite: `Project URL` ir `service_role key` (Project Settings → API)
4. Eikite į **SQL Editor** → paleiskite `supabase-schema.sql` turinį

### 2. Resend (el. paštas) – NEMOKAMA iki 100/mėn
1. Eikite į **resend.com** → Create account
2. Domains → Add domain (arba naudokite jų domeną testavimui)
3. API Keys → Create API Key → nukopijuokite `re_...`

### 3. Stripe (mokėjimai)
1. Eikite į **stripe.com** → Registruokitės
2. Dashboard → Developers → API keys → nukopijuokite `sk_live_...`
3. Products → Add product:
   - **Pro mėnesinis**: 29€ recurring/month → nukopijuokite Price ID
   - **Pro metinis**: 249€ recurring/year → nukopijuokite Price ID
4. Webhooks → Add endpoint: `https://JUSU-DOMENAS.vercel.app/api/stripe-webhook`
   → Events: `checkout.session.completed`, `customer.subscription.deleted`
   → nukopijuokite `whsec_...`

### 4. Anthropic API (Claude AI)
1. Eikite į **console.anthropic.com**
2. API Keys → Create Key → nukopijuokite `sk-ant-...`
3. Naujai paskyrai – gauna $5 kreditų (nemokama pradžiai)

### 5. Google Gemini (dideliems dokumentams) – NEMOKAMA
1. Eikite į **aistudio.google.com**
2. Get API key → nukopijuokite

### 6. GitHub
1. Eikite į **github.com** → New repository → `bidwise-ai`
2. Įkelkite visus failus į repo:
```bash
git init
git add .
git commit -m "initial commit"
git remote add origin https://github.com/JUSU_VARDAS/bidwise-ai.git
git push -u origin main
```

### 7. Vercel (hosting) – NEMOKAMAS
1. Eikite į **vercel.com** → prisijunkite per GitHub
2. Add New Project → pasirinkite `bidwise-ai` repo
3. Framework Preset: **Other**
4. Root Directory: `.` (palikite tuščią)
5. Spustelėkite **Deploy**

### 8. Vercel aplinkos kintamieji (BŪTINA)
Vercel Dashboard → Jūsų projektas → Settings → Environment Variables:

| Kintamasis | Reikšmė |
|------------|---------|
| `ANTHROPIC_API_KEY` | `sk-ant-...` |
| `GEMINI_API_KEY` | Jūsų Gemini raktas |
| `SUPABASE_URL` | `https://xxx.supabase.co` |
| `SUPABASE_SERVICE_KEY` | `eyJ...` |
| `RESEND_API_KEY` | `re_...` |
| `STRIPE_SECRET_KEY` | `sk_live_...` |
| `STRIPE_WEBHOOK_SECRET` | `whsec_...` |
| `STRIPE_PRICE_MONTHLY` | Stripe price ID mėnesiniam |
| `STRIPE_PRICE_YEARLY` | Stripe price ID metiniam |
| `FROM_EMAIL` | `info@jusudomenas.lt` |
| `JWT_SECRET` | Bet koks slaptas tekstas, pvz. `bidwise-2025-secret` |

Po kintamųjų įvedimo → **Redeploy**

---

## Kaštai

| Paslauga | Kaina |
|----------|-------|
| Vercel hosting | **NEMOKAMA** |
| Supabase (iki 500MB) | **NEMOKAMA** |
| Resend (iki 100 laiškų/mėn) | **NEMOKAMA** |
| Anthropic Claude API | ~0.08–0.15€ / analizė |
| Google Gemini (dideliems dok.) | **NEMOKAMA** (iki limito) |
| Stripe mokėjimų | 1.4% + 0.25€ / transakciją |
| Domenas .lt | ~10€ / metus |

**Viso mėnesiniai kaštai startui: ~0-5€** (priklausomai nuo analizių kiekio)

---

## AI modeliai

- **Claude claude-opus-4-5** – pagrindinis (tiksliausi rezultatai)
- **Gemini 1.5 Pro** – dideliems dokumentams (>80,000 simbolių)
- **PDF.js** – tekstui ištraukti iš PDF
- **Mammoth.js** – tekstui iš Word (.docx)
- **JSZip** – ZIP archyvų atvėrimui

---

## Verslo modelis

| | Nemokamas | Pro |
|--|-----------|-----|
| Analizės | 3 (visam laikui) | Neribota |
| PDF eksportas | ✓ | ✓ |
| El. pašto ataskaita | – | ✓ |
| Istorija | – | ✓ |
| Dideli dokumentai | – | ✓ |
| Kaina | 0€ | 29€/mėn arba 249€/metus |

**Pelnas nuo 1 Pro kliento**: ~28.60€/mėn (po Stripe komisinių)
